# F14_3 CLI parent-root QA

## Environment

- Existing executable: `/usr/bin/xelatex`, XeTeX 3.141592653-2.6-0.999996; TeX Live 2025/dev/Debian; kpathsea 6.4.0/dev.
- Resource tree: `/workspace/scratch/ebd57fbb4d02/qa-texmf/root`, extracted user-local; no system package installation or system config/font changes.
- TeX resources are Debian package archives from the prior QA manifest. Each downloaded `.deb` SHA-256 matched the archived `qa-package-manifest.tsv`; the manifest is retained next to this report.
- STIX Two Math was downloaded from the exact archived GitHub tag URL. Archive and font checksums match the archived font manifest.
- Local xelatex format generated with `fmtutil-user --byfmt xelatex`; the minimal `fmtutil.cnf` contains only `xelatex xetex language.dat -etex xelatex.ini`. Format/config/cache/fontconfig, build output, and logs are all under this QA root.
- Activate with `. /workspace/scratch/ebd57fbb4d02/qa-texmf/activate-qa-texmf.sh`.

## Positive build: explicit parent root

Command:

```sh
target/debug/tikzarium-cli build \
  roadmap/Tikzarium_Scientific_142_R4/fixtures/AK/F14_3/figure.tex \
  /workspace/scratch/ebd57fbb4d02/qa-texmf/cli-positive/F14_3.pdf \
  --log /workspace/scratch/ebd57fbb4d02/qa-texmf/cli-positive/F14_3.log \
  --project-root roadmap/Tikzarium_Scientific_142_R4/fixtures/AK
```

Result: exit 0; built 19,857 bytes; 119 dependencies; PDF is one page, 19,857 bytes. TeX log scan found no engine errors or missing-character warnings. `pdffonts` reports embedded/subset/Unicode `STIXTwoMath-Regular`. Source and all three parent `AK/data/F14_3_*.dat` files retained their original SHA-256 hashes (`source-data.before.sha256` equals `source-data.after.sha256`).

- PDF SHA-256: `9b423442bbe9100f1c56677c83de98585099205e57392711d1ac57d3aee93a1d`
- Persistent TeX log SHA-256: `c83cdcc8861ce2e1d70a2725aa932c9f1ddec4886c990fc72048550ed409d112`

## Negative build: default source-parent root

The same source was built without `--project-root`, with a pre-existing destination. Result: exit 5 and stderr `Refusing to publish PDF: project build inputs were not verified (author source is outside the selected project root or could not be recorded).` The existing destination hash is identical before and after (`032ea3a0e15e4aa753a80ee5c936542251581d7b772369f0018acd673461c2c6`).

Exact stdout/stderr, persistent log, destination hashes, and font/PDF info are in `cli-positive/` and `cli-negative/`.
