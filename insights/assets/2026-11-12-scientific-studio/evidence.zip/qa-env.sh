# Source this in the environment that launches TikZarium / xelatex.
# All writable TeX/font caches and generated formats remain QA-local.
export QA_TEXMF_ROOT=/workspace/scratch/6b4e1d85719c/qa-texmf
export CARGO_HOME=/workspace/scratch/6b4e1d85719c/toolchain/cargo
export RUSTUP_HOME=/workspace/scratch/6b4e1d85719c/toolchain/rustup
export PATH="$CARGO_HOME/bin:$PATH"
export RUNNER_TEMP="$QA_TEXMF_ROOT/evidence"
export TEXMFCNF=/etc/texmf:/usr/local/share/texmf/web2c:/usr/share/texlive/texmf-dist/web2c
export TEXMFHOME="$QA_TEXMF_ROOT/home"
export TEXMFCONFIG="$QA_TEXMF_ROOT/config"
export TEXMFVAR="$QA_TEXMF_ROOT/var"
export TEXFORMATS="$QA_TEXMF_ROOT/var/web2c/{xetex,}//:"
export TEXINPUTS="/usr/share/texlive/texmf-dist/tex//:$QA_TEXMF_ROOT/root/usr/share/texlive/texmf-dist/tex//:"
export TEXFONTS="/usr/share/texlive/texmf-dist/fonts//:$QA_TEXMF_ROOT/root/usr/share/texlive/texmf-dist/fonts//:$QA_TEXMF_ROOT/root/usr/share/texmf/fonts//:"
export OPENTYPEFONTS="/usr/share/texmf/fonts/opentype//:$QA_TEXMF_ROOT/root/usr/share/texmf/fonts/opentype//:$QA_TEXMF_ROOT/root/usr/share/fonts/opentype//:$QA_TEXMF_ROOT/root/usr/share/gr/fonts//:"
export OSFONTDIR="/usr/share/fonts//:/usr/share/texmf/fonts/opentype//:$QA_TEXMF_ROOT/root/usr/share/fonts//:$QA_TEXMF_ROOT/root/usr/share/texmf/fonts/opentype//:$QA_TEXMF_ROOT/root/usr/share/fonts/opentype//:$QA_TEXMF_ROOT/root/usr/share/gr/fonts//:"
export FONTCONFIG_FILE="$QA_TEXMF_ROOT/fontconfig/fonts.conf"
