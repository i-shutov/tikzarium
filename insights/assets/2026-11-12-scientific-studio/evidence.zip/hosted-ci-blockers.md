# Hosted native gates — observed failure audit

Candidate: `1784a48246cbdfd260fb80ce4731c7f165ad52c5`, PR #189.
Checked app/src tree: `19f95e0b07285dbb837daf49dd4c31331fb71b5f`.
Preserved reviewed native gate: `bf8ec7532f7c3f11d32567722828b43c83c17a7d`.

## linux-portable

[Original job](https://github.com/i-shutov/tikzarium/actions/runs/43181526493/job/131058410625).
Original retrieved log: `github-job-131058410625.log`.

First failure is the APP_TREE agreement check, before native build/launch/evidence:

```text
2026-11-12T08:16:06.6836029Z app_tree="$(git rev-parse HEAD:crates/tikzarium-app/src)"
2026-11-12T08:16:06.6836518Z grep -Fqx "APP_TREE = \"$app_tree\"" scripts/qa_i61_b42_studio_x11.py
2026-11-12T08:16:06.6928727Z ##[error]Process completed with exit code 1.
```

The artifact step subsequently reports no native output files. This job is a failed preserved source-tree gate, not a demonstrated application rendering failure and not native GUI PASS.

## studio-full-vertical

[Original job](https://github.com/i-shutov/tikzarium/actions/runs/43181526358/job/131058409575).
Original retrieved log: `github-job-131058409575.log`.

First failure is the pinned source-tree assertion, before the heavy TeX/native exercise:

```text
2026-11-12T08:16:16.4210401Z test "$(git rev-parse HEAD:crates/tikzarium-app/src)" = 'bf8ec7532f7c3f11d32567722828b43c83c17a7d'
2026-11-12T08:16:16.4298352Z ##[error]Process completed with exit code 1.
```

No original GUI screenshots or interaction results were uploaded by this job. The pointer coordinates and tree pin must be reviewed with new actual native screenshots before the gate is updated; it was not weakened in this PR.

These are observations for the named jobs/head only. Other jobs may still be running; this note does not assert all-green CI, physical Win10, IME, DPI or release acceptance.
