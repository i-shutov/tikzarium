# XeLaTeX fixture verification

## Environment

- Engine: `/usr/bin/xelatex`; XeTeX `3.141592653-2.6-0.999996` (TeX Live `2025/dev/Debian`); kpathsea `6.4.0/dev`.
- The disposable TeX/font resources and generated format are under `/workspace/scratch/6b4e1d85719c/qa-texmf`. No system TeX or fontconfig files were changed.
- Source `/workspace/scratch/6b4e1d85719c/qa-texmf/qa-env.sh` to reproduce the environment. It sets QA-local `TEXMFHOME`, `TEXMFCONFIG`, `TEXMFVAR`, and `TEXFORMATS`, explicit `TEXINPUTS`/font search paths, private `FONTCONFIG_FILE`, and `RUNNER_TEMP=/workspace/scratch/6b4e1d85719c/qa-texmf/evidence`.
- Debian Trixie `InRelease` signature verified with the installed Debian archive keyring; `Packages.xz` SHA256 matched the signed index. Every extracted archive's version, byte size, and SHA256 matched that index. Resource version/hash records are retained in the QA metadata.

## Commands and results

The commands below ran after sourcing `qa-env.sh`; both used the existing engine, disabled shell escape, and wrote output outside the fixture directories.

```sh
source /workspace/scratch/6b4e1d85719c/qa-texmf/qa-env.sh
cd /workspace/scratch/6b4e1d85719c/tikzarium/roadmap/Tikzarium_Scientific_142_R4/fixtures/SR/SV-001
/usr/bin/xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=/workspace/scratch/6b4e1d85719c/qa-texmf/qa-output/env-check-SV001 figure.tex
```

Exit code: **0**. PDF: `/workspace/scratch/6b4e1d85719c/qa-texmf/qa-output/env-check-SV001/figure.pdf` — SHA256 `8543788266101963a5907e1dd824c8b8d9847eb61810cf3cdb22fc095e5ece9b`. Copied compiler log: [sv001-xelatex.log](./sv001-xelatex.log) — SHA256 `d745154d6cc6f6a4695af0e0bb02e6283fc5d9eefaeb8d0d70b3bfec4e979292`.

```sh
source /workspace/scratch/6b4e1d85719c/qa-texmf/qa-env.sh
cd /workspace/scratch/6b4e1d85719c/tikzarium/roadmap/Tikzarium_Scientific_142_R4/fixtures/AK/F14_3
/usr/bin/xelatex -no-shell-escape -interaction=nonstopmode -halt-on-error -file-line-error -output-directory=/workspace/scratch/6b4e1d85719c/qa-texmf/qa-output/env-check-F14_3 figure.tex
```

Exit code: **0**. PDF: `/workspace/scratch/6b4e1d85719c/qa-texmf/qa-output/env-check-F14_3/figure.pdf` — SHA256 `cce4e3ee6d2b40da61a87d35f258658ace33f12cdad3143e021e5e0f064c14f3`. Copied compiler log: [ak-f14-3-xelatex.log](./ak-f14-3-xelatex.log) — SHA256 `cc9dc40628b0cabe1f57f9059f0f4c310e084fd0388d81ccf888ac56008abdd5`.

## Original input hashes and source integrity

| Input | SHA256 |
|---|---|
| `fixtures/SR/SV-001/figure.tex` | `d6f5f8ea1a5876b6ef191b07c8f7b35177fbe56ef152ed1ce564fbff66959301` |
| `fixtures/AK/F14_3/figure.tex` | `ec3b7bafb9f36c690c2e86bcd22c665f5c669e1f5d990ee310987f24b6f2880c` |
| `fixtures/AK/data/F14_3_left.dat` | `02a56c0ec4b924fbcd2bbe1520806a993b4fc2d0ded61aa139fea4650a576f6c` |
| `fixtures/AK/data/F14_3_middle.dat` | `47c689c3c41c05bc7813eabb5e910580d3eb21bb8a9459c2e46c5bd941f64efd` |
| `fixtures/AK/data/F14_3_right.dat` | `5c05b2e82698f87611cf069f794d14415f8ba993a8d3d560c98629e0854a4000` |

`git diff --quiet` passed for all five fixture/source-data files above. No fixture files were changed by these compilations.
