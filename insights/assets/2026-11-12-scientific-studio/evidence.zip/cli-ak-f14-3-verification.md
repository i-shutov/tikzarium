# TikZarium CLI build: AK/F14_3

- Result: exit code **0** (`cli-ak-f14-3.exit-code`). CLI reported `Built 19858 bytes in 7.851922256s; 118 dependencies` (`cli-ak-f14-3.stdout.log`). No GUI or Cargo command was run.
- Environment: sourced `/workspace/scratch/6b4e1d85719c/qa-texmf/qa-env.sh`, then set `TIKZARIUM_XELATEX=/usr/bin/xelatex`.
- Command, from `/workspace/scratch/6b4e1d85719c/tikzarium`:

```sh
target/debug/tikzarium-cli build roadmap/Tikzarium_Scientific_142_R4/fixtures/AK/F14_3/figure.tex /workspace/scratch/6b4e1d85719c/evidence/cli-ak-f14-3.pdf --log /workspace/scratch/6b4e1d85719c/evidence/cli-ak-f14-3.log
```

- PDF SHA256: `ce0fec99946ba3d3276fd1990bae77ff98e1266c4507189e08738d4789342759`.
- Compiler log SHA256: `5df91b044cdf3bb9d14cd4210928228876aa6be205d76c7252f33d63e8382172`.
- Captured CLI stdout/stderr: `cli-ak-f14-3.stdout.log`.

## Original inputs

| Input | SHA256 |
|---|---|
| `fixtures/AK/F14_3/figure.tex` | `ec3b7bafb9f36c690c2e86bcd22c665f5c669e1f5d990ee310987f24b6f2880c` |
| `fixtures/AK/data/F14_3_left.dat` | `02a56c0ec4b924fbcd2bbe1520806a993b4fc2d0ded61aa139fea4650a576f6c` |
| `fixtures/AK/data/F14_3_middle.dat` | `47c689c3c41c05bc7813eabb5e910580d3eb21bb8a9459c2e46c5bd941f64efd` |
| `fixtures/AK/data/F14_3_right.dat` | `5c05b2e82698f87611cf069f794d14415f8ba993a8d3d560c98629e0854a4000` |

The source declares these three data paths via `\datadir`. The CLI stdout reports only a dependency count, and the TeX log does **not** list the `.dat` filenames. Therefore the filenames above are source-declared inputs, not claims of `.fls` or log-confirmed file provenance. `git diff --quiet` passed for the source and all three data files.
